<!DOCTYPE html>
<html >
<head>
  <!-- Site made with Mobirise Website Builder v4.7.7, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.7.7, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/6c77d735f6558be69975bf428f536fd2-60x80-1-60x58.jpg" type="image/x-icon">
  <meta name="description" content="">
  <title>PrestaFami</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
  <section class="menu cid-qUuJBQgshs" once="menu" id="menu2-5">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    
                        <img src="assets/images/6c77d735f6558be69975bf428f536fd2-60x80-1-60x58.jpg" alt="Mobirise" title="" style="height: 3.8rem;">
                    
                </span>
                
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item dropdown">
                    <a class="nav-link link text-black display-4" href="index.html#header2-c"><span class="mbri-home mbr-iconfont mbr-iconfont-btn"></span>
                        Servicios</a>
                </li><li class="nav-item"><a class="nav-link link text-black display-4" href="index.html#form4-e"><span class="mbri-pin mbr-iconfont mbr-iconfont-btn"></span>Contáctenos</a></li><li class="nav-item"><a class="nav-link link text-black display-4"><span class="mbri-credit-card mbr-iconfont mbr-iconfont-btn"></span>Inicio Administrador</a></li></ul>
            
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.me/h"></a></section><section class="cid-qTkA127IK8 mbr-fullscreen" id="header2-1">

    

    

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">PRESTAFAMI</h1>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2"><strong>COOPERATIVA MULTIACTIVA PARA El APOYO FAMILIAR</strong></h3>
                
                <div class="mbr-section-btn"><a class="btn btn-md btn-black-outline display-7" href="index.html#header2-d">Leer Mas</a></div>
            </div>
        </div>
    </div>
    
</section>

<section class="cid-qUuOmpimCE mbr-fullscreen" id="header2-c">

    

    

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">
                    Servicios</h1>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2"><strong>¡ Asóciate y disfruta de todos los beneficios !
</strong><div>&nbsp;
</div><div>
</div><div><strong>¿Buscas recursos para proyectos productivos, que te ayuden con capital para realizar tu trabajo independiente? asóciate a la cooperativa Prestafami y recibe orientación, servicio de crédito o microcrédito y se mas productivo.</strong></div></h3>
                
                
            </div>
        </div>
    </div>
    
</section>

<section class="cid-qUuSMsU2JL mbr-parallax-background" id="header2-d">

    

    

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">
                    Nosotros</h1>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2"><strong>VISION:  La cooperativa multiactiva para el apoyo familiar “PRESTAFAMI” se visiona al futuro como una cooperativa desarrolladora de proyectos sociales, como herramienta indispensablepara el desarrollo social de la comunidad de su entorno.
</strong><div>&nbsp;
</div><div><strong>MISION: La cooperativa multiactiva para el apoyo familiar “PRESTAFAMI es una cooperativa dedicada al bienestar de sus asociados a través del servicio del microcrédito productivo, orientado a las personas naturales de estratos 1 al 3 en los municipios de Dosquebradas y Pereira del departamento de Risaralda, servicios ofrecidos en forma oportuna y solidaria, confiando en los pagos voluntarios por caja por parte de los asociados y orientados a mejorar sus condiciones sociales y económicas, apoyando la autogesión.</strong></div></h3>
                
                
            </div>
        </div>
    </div>
    
</section>

<section class="mbr-section form4 cid-qUvPBTY6Z8" id="form4-e">

    

    
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="google-map"><iframe frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0Dx_boXQiwvdz8sJHoYeZNVTdoWONYkU&amp;q=place_id:EitDcmEuIDggIzE4LTYyLCBQZXJlaXJhLCBSaXNhcmFsZGEsIENvbG9tYmlhIhoSGAoUChIJN3QqiUiHOI4RRrdCzKtrmTgQPg" allowfullscreen=""></iframe></div>
            </div>
            <div class="col-md-6">
                
                <div>
                    <div class="icon-block pb-3">
                        
                        
                    </div>
                    <div class="icon-contacts pb-3">
                        <h5 class="align-left mbr-fonts-style display-7">ration
                        </h5>
                        <p class="mbr-text align-left mbr-fonts-style display-7">Dirección: Cra 8 # 18 - 60 oficina 601<br>Teléfono:&nbsp;3136149377<br>Correo:&nbsp;cooperativaprestafami@gmail.com</p>
                    </div>
                </div>
                <div data-form-type="formoid">
                    <div data-form-alert="" hidden="">¡Gracias Por Completar El Formulario!</div>
                    <form class="block mbr-form" action="https://mobirise.com/" method="post" data-form-title="Mobirise Form"><input type="hidden" name="email" data-form-email="true" value="wOsizaT7YI7BMfsrFLWZeKwZaJtEqXUh4OhGcwF7LzzXHIsErxm0YvVdEb0sdIRZ6mFr3zXAzM+7E0Xrk0VocvyK0OEMqjyDDqvh4fM0c4xyimU6tP5V5knfDqQwEroL" data-form-field="Email">
                        <div class="row">
                            <div class="col-md-6 multi-horizontal" data-for="name">
                                <input type="text" class="form-control input" name="nombre" data-form-field="Name" placeholder="Nombre" required="" id="name-form4-e">
                            </div>
                            <div class="col-md-6 multi-horizontal" data-for="phone">
                                <input type="text" class="form-control input" name="telefono" data-form-field="Phone" placeholder="Teléfono" required="" id="phone-form4-e">
                            </div>
                            <div class="col-md-12" data-for="email">
                                <input type="text" class="form-control input" name="email" data-form-field="Email" placeholder="Correo" required="" id="email-form4-e">
                            </div>
                            <div class="col-md-12" data-for="message">
                                <textarea class="form-control input" name="mensaje" rows="3" data-form-field="Message" placeholder="Mensaje" style="resize:none" id="message-form4-e"></textarea>
                            </div>
                            <div class="input-group-btn col-md-12" style="margin-top: 10px;"><button href="" type="submit" class="btn btn-primary btn-form display-4">Enviar Mensaje</button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>