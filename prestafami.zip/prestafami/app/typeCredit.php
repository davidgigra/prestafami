<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class typeCredit extends Model
{
    protected $table = "typeCredits";
    protected $fillable = ['name'];
}